#include <io.h>
#include <delay.h>
#include <stdio.h>
#include <ff.h>

//C�digo base que reproduce A001.WAV que es un WAV, Mono, 8-bit, y frec de muestreo de 22050HZ
    
char bufferL[256];
char bufferH[256]; 
char NombreArchivo[]  = "0:A001.wav";
unsigned int i=0;
bit LeerBufferH,LeerBufferL;

interrupt [TIM1_COMPA] void timer1_compa_isr(void)
{
disk_timerproc();
/* MMC/SD/SD HC card access low level timing function */
}
        
//Interrupci�n que se ejecuta cada T=1/Fmuestreo_Wav
interrupt [TIM2_COMPA] void timer2_compa_isr(void)         
{
    if (i<256)
      OCR0A=bufferL[i++];
    else      
    {
      OCR0A=bufferH[i-256];
      i++;
    }   
    if (i==256)
       LeerBufferL=1;
    if (i==512)
    {
       LeerBufferH=1;
       i=0;
    }   
}

void main()
{
    unsigned int  br;
       
    /* FAT function result */
    FRESULT res;
                  
   
    /* will hold the information for logical drive 0: */
    FATFS drive;
    FIL archivo; // file objects 
                                  
    CLKPR=0x80;         
    CLKPR=0x01;         //Cambiar a 8MHz la frecuencia de operaci�n del micro 
       
    // C�digo para hacer una interrupci�n peri�dica cada 10ms
    // Timer/Counter 1 initialization
    // Clock source: System Clock
    // Clock value: 1000.000 kHz
    // Mode: CTC top=OCR1A
    // Compare A Match Interrupt: On
    TCCR1B=0x0A;     //CK/8 10ms con oscilador de 8MHz
    OCR1AH=0x27;
    OCR1AL=0x10;
    TIMSK1=0x02; 
                                                    
    //PWM para conversi�n Digital Anal�gica WAV->Sonido
    // Timer/Counter 0 initialization
    // Clock source: System Clock
    // Clock value: 8000.000 kHz
    // Mode: Fast PWM top=0xFF
    // OC0A output: Non-Inverted PWM
    TCCR0A=0x83;         
    
    DDRB.7=1;  //Salida bocina (OC0A)
                                  
    // Timer/Counter 2 initialization
    // Clock source: System Clock
    // Clock value: 1000.000 kHz
    // Mode: CTC top=OCR2A
    ASSR=0x00;
    TCCR2A=0x02;
    TCCR2B=0x02;
    OCR2A=0x2C;
        
    // Timer/Counter 2 Interrupt(s) initialization
    TIMSK2=0x02;
    
    DDRD.7=1;
    #asm("sei")   
    disk_initialize(0);  /* Inicia el puerto SPI para la SD */
    delay_ms(500);
    
    /* mount logical drive 0: */
    if ((res=f_mount(0,&drive))==FR_OK){  
        while(1)
        { 
            
        /*Lectura de Archivo*/
        res = f_open(&archivo, NombreArchivo, FA_OPEN_EXISTING | FA_READ);
        if (res==FR_OK){ 
            PORTD.7=1;
            f_read(&archivo, bufferL, 58,&br); //leer encabezado    
            
            f_read(&archivo, bufferL, 256,&br); //leer los primeros 512 bytes del WAV
            f_read(&archivo, bufferH, 256,&br);    
            LeerBufferL=0;     
            LeerBufferH=0;
            TCCR0B=0x01;    //Prende sonido
            do{   
                 while((LeerBufferH==0)&&(LeerBufferL==0));
                 if (LeerBufferL)
                 {                       
                     f_read(&archivo, bufferL, 256,&br); //leer encabezado
                     LeerBufferL=0;  
                 }
                 else
                 { 
                     f_read(&archivo, bufferH, 256,&br); //leer encabezado
                     LeerBufferH=0;
                    
                 }            
                 
                 //C�digo para estatus switches
                          
            }while(br==256);
            TCCR0B=0x00;   //Apaga sonido
            f_close(&archivo); 
            
        }              
        }
    }
    f_mount(0, 0); //Cerrar drive de SD
    while(1);
}
